docker network create es-01_network

docker run \
--name kib-01 \
--net es-01_network \
-p 5699:5601 \
-e "elasticsearch.hosts=http://es-node01:9299" \
-e "xpack.security.enabled=false" \
-e "xpack.monitoring.enabled=false" \
-e "xpack.watcher.enabled=false" \
-e "xpack.ml.enabled=false" \
docker.elastic.co/kibana/kibana:8.2.3
