docker network create es-01_network

docker run \
       -p 9299:9200 \
       -p 9399:9300 \
       --name es-node01 \
       --net es-01_network \
       -e "node.name=es01" \
       -e "cluster.name=es01_cluster" \
       -e "discovery.type=single-node" \
       -e "xpack.security.enabled=false" \
       -e "http.cors.enabled=true" \
       -e "http.cors.allow-origin=\"*\"" \
       -e "http.cors.allow-methods=OPTIONS, HEAD, GET, POST, PUT, DELETE" \
       -e "http.cors.allow-headers=X-Requested-With,X-Auth-Token,Content-Type,Content-Length" \
       -e "http.cors.allow-credentials=true" \
       docker.elastic.co/elasticsearch/elasticsearch:8.2.3
